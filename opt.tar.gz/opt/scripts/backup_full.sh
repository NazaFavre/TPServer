#!/bin/bash

# Funci�n ayuda
function mostrar_ayuda() {
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Realiza un backup del directorio ORIGEN y lo guarda en DESTINO."
    echo "Ejemplo: $0 /etc /backup_dir"
    exit 1
}

# Validar argumentos
if [ "$1" == "-h" ] || [ "$#" -ne 2 ]; then
    mostrar_ayuda
fi

ORIGEN=$1
DESTINO=$2

# Validar directorios y su montaje
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio origen $ORIGEN no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio destino $DESTINO no existe o no est� montado."
    exit 1
fi

# Generador de nombre del archivo con fecha actual formato YYYYMMDD
FECHA=$(date +%Y%m%d)
NOMBRE_BKP=$(basename $ORIGEN)_bkp_$FECHA.tar.gz

# Crear el backup
tar -czf $DESTINO/$NOMBRE_BKP $ORIGEN

# Mensaje
echo "Backup completado: $DESTINO/$NOMBRE_BKP"
